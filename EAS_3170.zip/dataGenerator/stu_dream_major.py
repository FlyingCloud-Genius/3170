majorList = ["Computer Science and Engineering", "Electronic Information Engineering", 
        "New Energy Science and Engineering", "Mathematics and Applied Mathematics", 
        "Statistics", "Bioinformatics", "Marketing and Communication", 
        "Global Business Studies", "Economics", "Finance", "Professional Accountancy"]