for i in range(300):
    app_id = "2" + str(i).zfill(9)
    resume = "www.resume.com/" + str