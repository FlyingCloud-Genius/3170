from django.apps import AppConfig


class GreExamConfig(AppConfig):
    name = 'GRE_exam'
