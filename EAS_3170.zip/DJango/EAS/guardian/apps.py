from django.apps import AppConfig


class GuardianConfig(AppConfig):
    name = 'guardian'
