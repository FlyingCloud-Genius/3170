from django.apps import AppConfig


class StuConfig(AppConfig):
    name = 'stu'
