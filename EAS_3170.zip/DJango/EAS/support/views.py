from django.shortcuts import render

# Create your views here.

def supportus(request):
    pass
    return render(request, 'support/supportus.html')