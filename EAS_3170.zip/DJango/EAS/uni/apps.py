from django.apps import AppConfig


class UniConfig(AppConfig):
    name = 'uni'
