import pymysql
import random

def data_generator():
    conn = pymysql.connect(host = "120.78.82.130", port = 3306, user = "root", passwd = "cuhksz", db = "AES", charset = "utf8")
    
    cursor = conn.cursor()

    current_id = 9000000000
    first_name = ["Johnson", "Williams", "Jones", "Brown", "Davis", 
    "Miller", "Wilson", "Moore", "Moore", "Anderson", "Mike", "Emily", "Ben", "Chandler", "Pheeby"]

    last_name = ["Jon", "Jack", "Kevin", "Oscar", "Petter", "Quentin", 
    "Emily", "Anna", "Kayla", "Zoe", "Sofia", "Amelia", "Yang", "William", "Bing", "Green", "Tribiony"]

    for i in range(10):
        email = random.randint(10000000, 99999999)
        random_phone = random.randint(17700000000, 17799999999)
        randomFName = random.randint(0, len(first_name) - 1)
        randomLName = random.randint(0, len(last_name) - 1)
        effect_row = cursor.execute('insert into adjudicator values("{}", "{}", "{}", "{}", "{}");'.format(str(current_id), str(email)+"@gmail.com", str(random_phone), first_name[randomFName], last_name[randomLName]))
        current_id += 1
        
    conn.commit()
    cursor.close()
    conn.close()

if __name__ == "__main__":
    data_generator()   
